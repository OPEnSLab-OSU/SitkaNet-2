---
name: Implementation Request
about: Describes a new item to integrate into Loom.
title: ''
labels: Implementation Request
assignees: ''

---

**Item's use**
Describe what it does, and what software functionality is needed to use it effectivly. Optionally: specify where in Loom the item would fit.

**Product Page**
Link to where the item is available for purchase.

**Existing Implementation**
Provide any existing Library or example code that is available.
